USE SCSIMS
GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[st_rpt_Stock]
(
    @Status_ID int
)
WITH ENCRYPTION
AS
BEGIN
    -- Zero Stock
    IF (@Status_ID = 1)
    BEGIN
        SELECT
            s.StockID,
            pi.Name + ISNULL(' ' + pi.Description, '') AS Description,
            CONVERT(decimal, s.SalePrice) AS SalePrice,
            CONVERT(decimal, s.TotalQuantity) AS TotalQuantity
        FROM Stock s
        INNER JOIN ProductInfo pi ON s.ProductID = pi.ProductID
        WHERE CONVERT(decimal, s.TotalQuantity) = 0
        ORDER BY s.StockID;
    END

    -- Current Stock
    ELSE IF (@Status_ID = 2)
    BEGIN
        SELECT DISTINCT
            pi.Name + ISNULL(' ' + pi.Description, '') AS Description,
            CONVERT(decimal, s.PurchasePrice) AS PurchasePrice,
            CONVERT(decimal, s.PurchasePrice) + 500 AS SalePrice,
            CONVERT(decimal, s.TotalQuantity) AS TotalQuantity
        FROM Stock s
        INNER JOIN ProductInfo pi ON s.ProductID = pi.ProductID
        WHERE s.TotalQuantity > 0
        ORDER BY TotalQuantity DESC;
    END

    -- Sales Report
    ELSE IF (@Status_ID = 3)
    BEGIN
        SELECT
            StockInOut.Date,
            pi.Name + ISNULL(' ' + pi.Description, '') AS Description,
            CONVERT(decimal, Stock.PurchasePrice) AS PurchasePrice,
            CONVERT(decimal, Stock.SalePrice) AS SalePrice,
            StockInOut.OutQuantity AS OutQuantity,
            StockInOut.Amount,
            StockInOut.Note,
            StockInOut.Amount - ((StockInOut.OutQuantity) * CONVERT(decimal, Stock.PurchasePrice)) AS Profit,
            (SELECT u.Username FROM Users u WHERE u.UserID = StockInOut.UserID) AS [User]
        FROM ProductInfo pi
        INNER JOIN Stock ON pi.ProductID = Stock.ProductID
        INNER JOIN StockInOut ON Stock.StockID = StockInOut.StockID
        WHERE StockInOut.OutQuantity != 0
          AND StockInOut.Note LIKE N'%خرڅ شو په بیل نمبر%';
    END

    -- Cash
    ELSE IF (@Status_ID = 4)
    BEGIN
        SELECT CashID AS ID, Description, Receipt, Paid, Date
        FROM Cash;
    END

    -- Nawe Dawagane
    ELSE IF (@Status_ID = 8)
    BEGIN
        SELECT
            s.StockID,
            pi.Name + ISNULL(' ' + pi.Description, '') AS Description,
            CONVERT(DECIMAL(18,2), s.PurchasePrice) AS PurchasePrice,
            CONVERT(DECIMAL(18,2), s.SalePrice) AS SalePrice,
            CONVERT(DECIMAL(18,2), ISNULL(pdLast.Quantity, 0)) AS TotalQuantity,
            u.Username AS [User],
            pdLast.PurchaseID AS LastPurchaseID,
            siLast.LastDate AS LastStockIODate
        FROM Stock s
        INNER JOIN ProductInfo pi ON s.ProductID = pi.ProductID
        OUTER APPLY (
            SELECT TOP (1)
                pd.PurchaseID,
                pd.BarcodeNumber,
                pd.Quantity
            FROM PurchaseDetails pd
            WHERE pd.BarcodeNumber = s.BarcodeNo
              AND pd.ProductID = s.ProductID
            ORDER BY pd.PurchaseID DESC
        ) pdLast
        OUTER APPLY (
            SELECT TOP (1)
                si2.Date AS LastDate,
                si2.UserID
            FROM StockInOut si2
            WHERE si2.StockID = s.StockID
            ORDER BY si2.Date DESC, si2.StockIOID DESC
        ) siLast
        LEFT JOIN Users u ON u.UserID = siLast.UserID
        WHERE ISNULL(pdLast.Quantity, 0) > 0
        ORDER BY pdLast.PurchaseID DESC;
    END

    -- Nehaye Dawagane
    ELSE IF (@Status_ID = 9)
    BEGIN
        SELECT DISTINCT
            s.StockID,
            pi.Name + ISNULL(' ' + pi.Description, '') AS Description,
            CONVERT(decimal, s.PurchasePrice) AS PurchasePrice,
            CONVERT(decimal, s.SalePrice) AS SalePrice,
            CONVERT(decimal, s.TotalQuantity) AS TotalQuantity,
            CONVERT(decimal, pi.MinimumStock - s.TotalQuantity) AS RequiredQuantity
        FROM Stock s
        INNER JOIN ProductInfo pi ON s.ProductID = pi.ProductID
        WHERE s.TotalQuantity <= pi.MinimumStock
          AND (pi.MinimumStock - s.TotalQuantity) > 0
          AND pi.isDelete = 0
        ORDER BY s.StockID;
    END

    -- Da Malono Sarana
    ELSE IF (@Status_ID = 10)
    BEGIN
        SELECT
            s.StockID,
            pi.Name + ISNULL(' ' + pi.Description, '') AS Name,
            si.InQuantity,
            si.OutQuantity,
            si.Note AS Description,
            si.Date,
            (SELECT u.Username FROM Users u WHERE u.UserID = si.UserID) AS [User]
        FROM Stock s
        INNER JOIN ProductInfo pi ON s.ProductID = pi.ProductID
        INNER JOIN StockInOut si ON s.StockID = si.StockID
        ORDER BY si.Date DESC;
    END
END
GO
